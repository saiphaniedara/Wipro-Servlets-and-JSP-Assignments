

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayCookiesServlet
 */
@WebServlet("/DisplayCookiesServlet")
public class DisplayCookiesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayCookiesServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter(); 
		Cookie[] cookies = request.getCookies();
		if(cookies == null)
		{
			out.println("<h3>No Cookies</h3>");
		}
		else
		{
			out.print("<table><tr><th>Cookie Name</th><th>Cookie Value</th></tr>");
			for(Cookie c : cookies )
			{
				out.println("<tr><td>"+c.getName()+"</td><td>"+c.getValue()+"</tr>");
			}
			out.print("</table>");
		}
	}



}
